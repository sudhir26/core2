﻿using System;

namespace myApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Number");
            int firstnumber = int.Parse(Console.ReadLine());
 
            Console.WriteLine("Enter Second Number");
            int secondnumber = int.Parse(Console.ReadLine());

           int sum = firstnumber + secondnumber;

           Console.WriteLine("Sum is {0}", sum);
           Console.Read();
        }
    }
}
